from django.db import connections
import datetime

def getLocalNumbers(Prov:str, City:str, Dist:str) -> dict:
    #print(Prov,City,Dist)
    cursor = connections['default'].cursor()

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected WHERE InProv LIKE %s AND InCity LIKE %s AND InDistrict Like %s;",(Prov,City,Dist))
    ResDict = {'LocalInfected' : cursor.fetchone()[0]}

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected NATURAL JOIN Recovered WHERE InProv LIKE %s AND InCity LIKE %s AND InDistrict Like %s;",(Prov,City,Dist))
    ResDict.update({'LocalRecovered' : cursor.fetchone()[0]})

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected NATURAL JOIN DeadCase WHERE InProv LIKE %s AND InCity LIKE %s AND InDistrict Like %s;",(Prov,City,Dist))
    ResDict.update({'LocalDead' : cursor.fetchone()[0]})

    ResDict.update({'LocalCurrent' : ResDict['LocalInfected'] - ResDict['LocalRecovered'] - ResDict['LocalDead']})

    NowTime = datetime.date.today()
    today = NowTime.isoformat()

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected WHERE InProv LIKE %s AND InCity LIKE %s AND InDistrict Like %s AND ConfirmTime = %s;",(Prov,City,Dist,today))
    ResDict.update({'NewInfected' : cursor.fetchone()[0]})

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected NATURAL JOIN Recovered WHERE InProv LIKE %s AND InCity LIKE %s AND InDistrict Like %s AND RecoverTime = %s;",(Prov,City,Dist,today))
    ResDict.update({'NewRecovered' : cursor.fetchone()[0]})

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected NATURAL JOIN DeadCase WHERE InProv LIKE %s AND InCity LIKE %s AND InDistrict Like %s AND DeadTime = %s;",(Prov,City,Dist,today))
    ResDict.update({'NewDead' : cursor.fetchone()[0]})

    ResDict.update({'NewCurrent' : ResDict['NewInfected'] - ResDict['NewRecovered'] - ResDict['NewDead']})

    cursor.close()
    return ResDict


def QueryTest(Id:str, Prov:str, City:str, TimeLimit:str) ->tuple:
    cursor = connections['default'].cursor()

    exe = '''SELECT TestCase.Id, TestCase.TestTime, TestCase.Resault, Officer.WorkProv, Officer.WorkCity
    FROM TestCase JOIN Officer ON TestCase.Sampler = Officer.Id
    WHERE TestCase.Id = %s AND Officer.WorkProv LIKE %s AND Officer.WorkCity LIKE %s AND TestTime >= %s
    '''
    cursor.execute(exe,(Id,Prov,City,TimeLimit))

    res = cursor.fetchall()
    cursor.close()
    return res


def nameIdVerify(id:str, name:str) -> bool :
    cursor = connections['default'].cursor()
    cursor.execute("SELECT FirstName, LastName FROM Resident WHERE id = %s",(id))

    p = cursor.fetchone()
    if p == None:
        return False
    
    if (p[1] + p[0]) == name :
        return True

    return False 
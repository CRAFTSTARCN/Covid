from django.shortcuts import render, redirect
from BaseInfo import query, info
from django.http import JsonResponse
from django.core.handlers.wsgi import WSGIRequest
from django.db import connections
from hashlib import sha256

# Create your views here.

def getMyNotify(id:str) -> list:
    NotifyList = []
    cursor = connections['default'].cursor()
    cursor.execute("SELECT Nid, Title, PublishTime FROM Notify WHERE AdminId = %s AND Deleted = 0 ORDER BY PublishTime DESC LIMIT 5;", (id))
    Notifies = cursor.fetchall()
    #print(Notifies)
    for tu in Notifies:
        NotifyList.append({'id' : tu[0], 'title' : tu[1], 'time' : tu[2].strftime("%Y-%m-%d")})

    cursor.close()
    return NotifyList

def ad(request : WSGIRequest):
    if request.session.get('adminId','') == '':
        return redirect('/')

    adDict = query.getLocalNumbers( request.session.get('WorkProv'),request.session.get('WorkCity'),'%')
    adDict.update({'WorkPlace' : request.session.get('WorkProv') + request.session.get('WorkCity')})
    adDict.update({'NotifyList' : getMyNotify(request.session.get('adminId'))})
    return render(request,'admin_main_page.html',adDict)

def officer(request : WSGIRequest):
    if request.session.get('userId','') == '':
        return redirect('/')
    
    offDict = query.getLocalNumbers(request.session.get('WorkProv'),request.session.get('WorkCity'),'%')
    offDict.update({'Name' : request.session.get('userName'), 'WorkPlace' : request.session.get('WorkProv') + request.session.get('WorkCity')})

    if request.session.get('userDuty') == 3:
        return render(request,'officer_main_page.html',offDict)
    elif request.session.get('userDuty') == 2:
        return render(request,'sampler_main_page.html',offDict)
    elif request.session.get('userDuty') == 1:
        return render(request,'investigator_main_page.html',offDict)

    return redirect('/')

def logout(request : WSGIRequest):
    request.session.delete()
    return redirect('/')

def changeSecretPage(request : WSGIRequest):

    loginAsAdmin, loginAsOfficer = False, False
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    uChe = ''
    if adId != '':
        loginAsAdmin = True
    elif uid != '':
        loginAsOfficer = True
        uChe = request.session.get('userDuty',0)
        if uChe == 0:
            loginAsOfficer = False
        else:
            uChe = info.OFFICER.get(uChe)
    
    if (not loginAsAdmin) and (not loginAsOfficer):
        return redirect('/')
    
    rendDict = {'loginAsAdmin':loginAsAdmin, 'loginAsOfficer':loginAsOfficer, 'Role':uChe}
    return render(request,'privatePages/changeSecret.html',rendDict)

def changeSecret(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})
    if request.session.get('adminId','') == '' and request.session.get('userId','') == '':
        return JsonResponse({'code' : -1, 'message' : 'no login infomation'})
    
    o,n = request.POST.get('OldPassword'), request.POST.get('NewPassword')

    hasher = sha256()
    hasher.update(o.encode('utf-8'))
    hasher_2  = sha256()
    exe = ''
    updid = ''
    if request.session.get('userId','') != '':
        if hasher.hexdigest() != request.session.get('userKey'):
            return JsonResponse({'code' : -1, 'message' : 'wrong password'})
        hasher_2.update(n.encode('utf-8'))
        request.session['userKey'] = hasher_2.hexdigest()
        exe = "UPDATE Officer SET Pass = %s WHERE Id = %s"
        updid = request.session.get('userId')
    else :
        if hasher.hexdigest() != request.session.get('adminKey'):
            return JsonResponse({'code' : -1, 'message' : 'wrong password'})
        hasher_2.update(n.encode('utf-8'))
        request.session['adminKey'] = hasher_2.hexdigest()
        exe = "UPDATE Administrator SET Pass = %s WHERE Id = %s"
        updid = request.session.get('adminId')
    
    cursor = connections['default'].cursor()
    cursor.execute(exe,(hasher_2.hexdigest(),updid))
    connections['default'].commit()
    cursor.close()

    return JsonResponse({'code' : 1, 'message' : 'success'})

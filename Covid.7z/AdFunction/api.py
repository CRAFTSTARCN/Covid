from django.shortcuts import render, redirect
from django.db import connections, transaction
from django.core.handlers.wsgi import WSGIRequest
from django.http import JsonResponse, HttpResponse
from hashlib import sha256
import datetime


def insertNewOfficer(request : WSGIRequest):
    if request.method == 'GET' or request.session.get('adminId','') == '':
        return JsonResponse({'code' : -1, 'message' : 'API fault'})

    nid,nname,npass,nduty = request.POST.get('NewOffId'),request.POST.get('NewOffName'),request.POST.get('NewOffPass'),request.POST.get('NewOffDuty')
    nduty = int(nduty)
    
    cursor = connections['default'].cursor()
    cursor.execute("SELECT FirstName, LastName FROM Resident WHERE Id = %s",nid)
    person = cursor.fetchone()

    if person == None :
        return JsonResponse({'code' : -1, 'message' : '查无此人'})
    
    if person[1] + person[0] != nname :
        return JsonResponse({'code' : -1, 'message' : '证件号码与姓名对应错误'})
    
    passer = sha256()
    passer.update(npass.encode('utf-8'))
    npass = passer.hexdigest()

    try:
        cursor.execute("INSERT INTO Officer VALUES(%s,%s,%s,%s,%s)",(nid,npass,nduty,request.session.get('WorkProv'),request.session.get('WorkCity')))
    except Exception as e:
        print(e)
        connections['default'].rollback()
        cursor.close()
        return JsonResponse({'code' : -1, 'message' : 'insert error'})
    
    connections['default'].commit()
    return JsonResponse({'code' : 1, 'message' : 'success'})


def insertNotify(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Fault : Request Error'})
    if request.session.get('adminId','') == '':
        return JsonResponse({'code' : -1, 'message' : 'No Permition'})
     
    t,b = request.POST.get('Title'), request.POST.get('Body')
    time = datetime.datetime.now()
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S")

    cursor = connections['default'].cursor()
    cursor.execute("SELECT COUNT(*) FROM Notify")
    nid = cursor.fetchone()[0]

    exe = ''' INSERT INTO Notify
    VALUES(%s,%s,%s,%s,%s,0);
    '''

    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(t,b,request.session.get('adminId'),nowtime,nid))
    except Exception as e:
        connections['default'].rollback()
        print(e)
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Insert Error'})

    connections['default'].commit()
    transaction.set_autocommit(True)
    cursor.close()
    return JsonResponse({'code' : 1, 'message' : 'success', 'newId' : nid})
     

def deleteNotify(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Fault : Request Error'})
    if request.session.get('adminId','') == '':
        return JsonResponse({'code' : -1, 'message' : 'No Permition'})
    
    n = request.POST.get('NotifyId')
    if not n.isdigit():
        return JsonResponse({'code' : -1, 'message' : 'Wrong Notify Id'})

    n = int(n)
    cursor = connections['default'].cursor()

    cursor.execute("SELECT AdminId FROM Notify WHERE Nid=%s",n)
    ad = cursor.fetchone()
    if ad == None or ad[0] != request.session.get('adminId',''):
        cursor.close()
        return JsonResponse({'code' : -1, 'message' : 'Invalid Notify'})

    exe = '''UPDATE Notify 
    SET Deleted = 1 
    WHERE Nid = %s
    '''

    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(n))
    except Exception as e:
        connections['default'].rollback()
        print(e)
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Insert Error'})

    connections['default'].commit()
    transaction.set_autocommit(True)
    cursor.close()
    return JsonResponse({'code' : 1, 'message' : 'success'})
from django.urls import path, include
from AdFunction import views, api

urlpatterns = [
    path('insertoff/',api.insertNewOfficer),
    path('InsertNotify/', views.insertNotifyPage),
    path('insertntf/', api.insertNotify),
    path('MyNotify/', views.allNotifyPage),
    path('delntf/', api.deleteNotify),
]
from django.urls import path, include
from OffFunction import views,api

urlpatterns = [
    path('gettest/', api.doctorGetTestInfo),
    path('mark/', api.markOne),
    path('InsertInfected/', views.insertInfectedPage),
    path('insertinf/', api.insertInfected),
    path('InsertRecovered/', views.insertRecoveredPage),
    path('insertrec/', api.insertRecovered),
    path('InsertDead/', views.insertDeadPage),
    path('insertdea/', api.insertDead),
    path('QueryInfected/', views.queryInfectedPage),
    path('queryinf/',api.queryInfected),
    path('Case/', views.infectedPage),
    path('BatchMark/', views.batchMarkPage),
    path('batchq/', api.batchQuery),
    path('batchmk/', api.batchMark),
    path('inserttst/', api.insertTestCase),
]
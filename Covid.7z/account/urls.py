from django.contrib import admin
from django.urls import path, include
from account import views

urlpatterns = [
    path('login/', include('login.urls')),
    path('admin/', views.ad),
    path('officer/', views.officer),
    path('logout/', views.logout),
    path('ChangeSecret/', views.changeSecretPage),
    path('changesec/', views.changeSecret),
]
from django.apps import AppConfig


class OfffunctionConfig(AppConfig):
    name = 'OffFunction'

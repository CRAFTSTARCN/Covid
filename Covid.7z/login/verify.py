from django.db import connections
from hashlib import sha256

def verification(loginTable, id, password):
    cursor = connections['default'].cursor()
    if loginTable == 'Administrator':
        cursor.execute("SELECT * FROM Administrator WHERE AdminId = %s",[id])
    else:
        cursor.execute("SELECT * FROM Officer WHERE Id = %s",[id])
    user = cursor.fetchone()
    cursor.close()

    if user == None:
        return None
    hasher = sha256()
    hasher.update(password.encode('utf-8'))
    if hasher.hexdigest() == user[1]:
        return user
    return None 
    
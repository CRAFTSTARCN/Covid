from django.apps import AppConfig


class HomepageConfig(AppConfig):
    name = 'HomePage'

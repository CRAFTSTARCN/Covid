from django.shortcuts import render, redirect
from django.db import connections
from django.core.handlers.wsgi import WSGIRequest
from django.http import JsonResponse, HttpResponse
from hashlib import sha256

# Create your views here.

def insertNotifyPage(request : WSGIRequest):
    if request.session.get('adminId','') == '':
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    if request.method == 'POST' :
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})
    
    rendDict = {'WorkPlace' : request.session.get('WorkProv') + request.session.get('WorkCity')}
    return render(request,'privatePages/insertNotifications.html',rendDict)

def allNotifyPage(request : WSGIRequest):
    if request.session.get('adminId','') == '':
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    if request.method == 'POST' :
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})
    
    rendDict = {'WorkPlace' : request.session.get('WorkProv') + request.session.get('WorkCity')}
    cursor = connections['default'].cursor()

    NotifyList = []
    cursor.execute('SELECT Title, PublishTime, Nid FROM Notify WHERE AdminId = %s AND Deleted = 0',(request.session.get('adminId')))
    nres = cursor.fetchall()

    for tu in nres:
        NotifyList.append(list(tu))
    
    rendDict.update({'NotifyList' : NotifyList})
    return render(request,'privatePages/adminNotify.html',rendDict)

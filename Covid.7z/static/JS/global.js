function clearAll () {
    $('input').val('');
}

function getStrMD(s) {
    return s <= 10 ? '0' + s : s.toString();
}

 function getToday() {
     var today = new Date();
     return today.getFullYear().toString() + '-' + getStrMD(today.getMonth()+1) + '-' + getStrMD(today.getDate())
 }
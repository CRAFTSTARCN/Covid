from django.shortcuts import render
from django.http import HttpRequest, HttpResponse, JsonResponse
from BaseInfo import info, query
from django.core.handlers.wsgi import WSGIRequest
from django.db import connections
import datetime

# Create your views here.

def getHomePageInfo() -> dict:
    infoDict = dict()

    now = datetime.date.today()
    today = now.isoformat()

    cursor = connections['default'].cursor()
    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected;")
    infoDict.update({'TotalInfected' : cursor.fetchone()[0]})
    cursor.execute("SELECT COUNT(CaseNumber) FROM Recovered;")
    infoDict.update({'TotalRecovered' : cursor.fetchone()[0]})
    cursor.execute("SELECT COUNT(CaseNumber) FROM DeadCase;")
    infoDict.update({'TotalDead' : cursor.fetchone()[0]})
    infoDict.update({'CurrentInfected' : infoDict['TotalInfected'] - infoDict['TotalRecovered'] - infoDict['TotalDead']})
    cursor.execute("SELECT COUNT(*) FROM CloseContact;")
    infoDict.update({'CloseContact' : cursor.fetchone()[0]})
    cursor.execute("SELECT COUNT(*) FROM CloseContact WHERE TestResault = 'U';")
    infoDict.update({'UncheckContact' : cursor.fetchone()[0]})
    cursor.execute("SELECT COUNT(*) FROM TestCase;")
    infoDict.update({'TotalTest' : cursor.fetchone()[0]})

    cursor.execute("SELECT COUNT(CaseNumber) FROM Infected WHERE ConfirmTime = %s;",today)
    infoDict.update({'NewInfected' : cursor.fetchone()[0]})
    cursor.execute("SELECT COUNT(CaseNumber) FROM Recovered WHERE RecoverTime = %s;",today)
    infoDict.update({'NewRecovered' : cursor.fetchone()[0]})
    cursor.execute("SELECT COUNT(CaseNumber) FROM DeadCase WHERE DeadTime = %s;",today)
    infoDict.update({'NewDead' : cursor.fetchone()[0]})
    infoDict.update({'NewCurrentInfected' :  infoDict['NewInfected'] - infoDict['NewRecovered'] - infoDict['NewDead']})
    cursor.execute("SELECT COUNT(*) FROM TestCase WHERE TestTime = %s;",today)
    infoDict.update({'NewTest' : cursor.fetchone()[0]})
    cursor.close()

    return infoDict

def getNotify() -> list:
    NotifyList = []
    cursor = connections['default'].cursor()
    cursor.execute("SELECT Nid, Title, AdminId, PublishTime, WorkProv, WorkCity FROM Notify NATURAL JOIN Administrator WHERE Deleted = 0 ORDER BY PublishTime DESC LIMIT 5;")
    Notifies = cursor.fetchall()
    for tu in Notifies:
        NotifyList.append({'id' : tu[0], 'title' : tu[1], 'publisher' : tu[4]+tu[5]+"管理员", 'time' : tu[3].strftime("%Y-%m-%d")})
    
    cursor.close()
    return NotifyList

def home(request : WSGIRequest):
    loginAsAdmin, loginAsOfficer = False, False
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    uChe = ''
    if adId != '':
        loginAsAdmin = True
    elif uid != '':
        loginAsOfficer = True
        uChe = request.session.get('userDuty',0)
        if uChe == 0:
            loginAsOfficer = False
        else:
            uChe = info.OFFICER.get(uChe)

    homePageDict = getHomePageInfo()
    homePageDict.update({'NotifyList' : getNotify()})
    homePageDict.update({'loginAsAdmin':loginAsAdmin, 'loginAsOfficer':loginAsOfficer, 'Role':uChe})

    return render(request,'index.html',homePageDict)


def getLocalData(request : WSGIRequest) :
    p,c,d = request.GET.get('Prov'),request.GET.get('City'),request.GET.get('Dist')
    return JsonResponse(query.getLocalNumbers(p,c,d))


def notifyPage(request : WSGIRequest):

    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})

    n = request.GET.get('nid','')
    if not n.isdigit():
        return JsonResponse({'code' : -1, 'message' : 'Wrong Notify Number'})
    n = int(n)

    loginAsAdmin, loginAsOfficer = False, False
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    uChe = ''
    if adId != '':
        loginAsAdmin = True
    elif uid != '':
        loginAsOfficer = True
        uChe = request.session.get('userDuty',0)
        if uChe == 0:
            loginAsOfficer = False
        else:
            uChe = info.OFFICER.get(uChe)
    
    rendDict = {'loginAsAdmin':loginAsAdmin, 'loginAsOfficer':loginAsOfficer, 'Role':uChe}
    cursor = connections['default'].cursor()
    cursor.execute("SELECT Title, Body, PublishTime, WorkProv, WorkCity, AdminId FROM Notify NATURAL JOIN Administrator WHERE Nid = %s AND Deleted = 0;",(n))
    nres = cursor.fetchone()
    
    if nres == None:
        return JsonResponse({'code' : -1, 'message' : 'None Such Notify'})
    rendDict.update({'NotifyTitle' : nres[0], 'PublishTime' : nres[2], 'Publisher' : nres[3] + nres[4] + '管理员', 'NotifyBody' : nres[1].replace('<','&lt;').replace('>','&gt;').replace('\n','<br>').replace(' ','&nbsp;')})
    if nres[-1] == request.session.get('adminId',''):
        rendDict.update({'MyNotify' : True, 'NotifyId' : n})
    return render(request, 'publicPages/notifyPage.html',rendDict)


def allNotify(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})

    loginAsAdmin, loginAsOfficer = False, False
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    uChe = ''
    if adId != '':
        loginAsAdmin = True
    elif uid != '':
        loginAsOfficer = True
        uChe = request.session.get('userDuty',0)
        if uChe == 0:
            loginAsOfficer = False
        else:
            uChe = info.OFFICER.get(uChe)
    
    rendDict = {'loginAsAdmin':loginAsAdmin, 'loginAsOfficer':loginAsOfficer, 'Role':uChe}
    
    cursor = connections['default'].cursor()
    cursor.execute("SELECT Title, PublishTime, Nid, WorkProv, WorkCity FROM Notify NATURAL JOIN Administrator WHERE Deleted = 0 ORDER BY PublishTime DESC;")
    an = cursor.fetchall()

    NotifyList = []
    for tu in an:
        NotifyList.append(list(tu))
    cursor.close()

    rendDict.update({'NotifyList' : NotifyList})
    return render(request,'publicPages/allNotify.html',rendDict)


def queryPersonalTestPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})

    loginAsAdmin, loginAsOfficer = False, False
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    uChe = ''
    if adId != '':
        loginAsAdmin = True
    elif uid != '':
        loginAsOfficer = True
        uChe = request.session.get('userDuty',0)
        if uChe == 0:
            loginAsOfficer = False
        else:
            uChe = info.OFFICER.get(uChe)
    
    rendDict = {'loginAsAdmin':loginAsAdmin, 'loginAsOfficer':loginAsOfficer, 'Role':uChe}
    return render(request,'publicPages/queryTest.html',rendDict)


def queryPersonalTest(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Request Error'})
    
    i,n = request.GET.get('Id'),request.GET.get('Name')
    valid = query.nameIdVerify(i,n)
    if not valid :
        return JsonResponse({'code' : -1, 'message' : 'ID 姓名错误'})
    t = request.GET.get('TimeLimit')
    
    ResList = []
    TestResDict = {'U' : '检测中', 'P' : '阳性', 'N' : '阴性'}
    res = query.QueryTest(i,'%','%',t)
    for tu in res:
        ResList.append([n,tu[1],tu[3]+tu[4],TestResDict[tu[2]]])
    return JsonResponse({'code' : 1, 'message' : 'success','ResList' : ResList})
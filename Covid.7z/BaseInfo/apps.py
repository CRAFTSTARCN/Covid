from django.apps import AppConfig


class BaseinfoConfig(AppConfig):
    name = 'BaseInfo'

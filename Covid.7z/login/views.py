from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.core.handlers.wsgi import WSGIRequest
from login import verify

# Create your views here.

def loginOfficer(request : WSGIRequest):
    return render(request,'login_doctor.html')

def loginAdmin(request : WSGIRequest):
    return render(request,'login_admin.html')

def checkAdmin(request : WSGIRequest):
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    if uid != '' or adId != '':
        return JsonResponse({'code' : 2})
    
    if request.method == 'GET':
        return redirect('/login/admin/')
    res = verify.verification('Administrator',request.POST.get('adId'),request.POST.get('inputPass'))
    if res == None:
        return JsonResponse({'code' : -1})
    
    request.session['adminId'] = res[0]
    request.session['adminKey'] = res[1]
    request.session['WorkProv'] = res[2]
    request.session['WorkCity'] = res[3]
    return JsonResponse({'code' : 1})

def checkOfficer(request : WSGIRequest):
    uid  = request.session.get('userId','')
    adId = request.session.get('adminId','')
    if uid != '' or adId != '':
        return JsonResponse({'code' : 2})
    
    if request.method == 'GET':
        return redirect('/login/admin/')
    res = verify.verification('Officer',request.POST.get('userId'),request.POST.get('inputPass'))
    if res == None:
        return JsonResponse({'code' : -1})
    
    cursor = verify.connections['default'].cursor()
    cursor.execute("SELECT FirstName, LastName FROM Resident WHERE Id = %s", [res[0]])
    name = cursor.fetchone()

    request.session['userId'] = res[0]
    request.session['userName'] = name[1] + name[0]
    request.session['userKey'] = res[1]
    request.session['userDuty'] = res[2]
    request.session['WorkProv'] = res[3]
    request.session['WorkCity'] = res[4]
    cursor.close()
    return JsonResponse({'code' : 1})
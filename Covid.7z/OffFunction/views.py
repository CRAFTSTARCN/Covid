from django.shortcuts import render
from django.http import JsonResponse
from django.core.handlers.wsgi import WSGIRequest
from BaseInfo import query, info
from django.db import connections
import datetime

# Create your views here.

def insertInfectedPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Requesy Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})

    SpanId = request.GET.get('spanId',"")
    rendDict = {'Name' : request.session.get('userName'), 'SpanId' : SpanId}
    rendDict.update({'DistList' : info.getDist(request.session.get('WorkProv'), request.session.get('WorkCity'))})
    return render(request,'privatePages/insertInfected.html',rendDict)


def insertRecoveredPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Requesy Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    
    rendDict = {'Name' : request.session.get('userName')}
    return render(request,'privatePages/insertRecovered.html',rendDict)


def insertDeadPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Requesy Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    
    rendDict = {'Name' : request.session.get('userName')}
    return render(request,'privatePages/insertDeath.html',rendDict)


def queryInfectedPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Requesy Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    
    rendDict = {'Name' : request.session.get('userName')}
    return render(request,'privatePages/queryInfected.html')


def infectedPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Requesy Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    
    c = request.GET.get('cid','')
    if not c.isdigit():
        return JsonResponse({'code' : -1, 'message' : 'wrong case number'})
    
    c = int(c)

    qexe = '''SELECT CaseNumber, LastName, FirstName, Id, ConfirmTime,
    InProv, InCity, InDistrict,
    CaseNumber IN (SELECT CaseNumber FROM Recovered) rec,
    CaseNumber IN (SELECT CaseNumber FROM DeadCase) dea
    FROM Infected NATURAL JOIN Resident
    WHERE CaseNumber = %s;
    ''' 

    rendDict = {'Name' : request.session.get('userName')}
    cursor = connections['default'].cursor()

    cursor.execute(qexe,(c))
    qres = cursor.fetchone()

    rendDict.update({'CaseNumber' : qres[0], 'InfectedName' : qres[1] + qres[2], 'InfectedId' : qres[3]})
    rendDict.update({'InfectedTime' : qres[4], 'InfectedPlace' : qres[5] + qres[6] + qres[7]})

    out = qres[8] + qres[9]
    status = '治疗中'
    ot = ''
    if qres[8] == 1 :
        status = '治愈'
        cursor.execute("SELECT RecoverTime FROM Recovered WHERE CaseNumber = %s",(c))
        ot = cursor.fetchone()
        ot = ot[0] if ot != None else ''
    elif qres[9] == 1:
        status = '死亡'
        cursor.execute("SELECT DeadTime FROM DeadCase WHERE CaseNumber = %s",(c))
        ot = cursor.fetchone()
        ot = ot[0] if ot != None else ''

    rendDict.update({'status' : status, 'out' : out, 'StatusTime' : ot})

    TrafficList = []
    cursor.execute("SELECT * FROM Traffic WHERE CaseNumber = %s",(c))
    tres = cursor.fetchall()
    for tu in tres:
        TrafficList.append(list(tu))
    
    ContactList = []
    cursor.execute("SELECT Id, LastName, FirstName, LivingProv, LivingCity, LivingDistrict, ContactTime, TestResault FROM CloseContact NATURAL JOIN Resident WHERE CaseNumber = %s",(c))
    cres = cursor.fetchall()
    for tu in tres:
        ContactList.append(list(tu))
    
    cursor.close()
    rendDict.update({'TrafficList' : TrafficList, 'ContactList' : ContactList})

    return render(request,'privatePages/infectedPage.html',rendDict)


def batchMarkPage(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'Requesy Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'Permition Error'})
    
    rendDict = {'Name' : request.session.get('userName')}
    return render(request,'privatePages/batchMark.html',rendDict)
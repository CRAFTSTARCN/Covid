TEYVAT = {
    'Mondstadt省' : {
        'code' : '00',
        'subCity': {
            'G市' : {
                'code' : '01',
                'subDist' : {'F区' : '01'},
            },
            'X市' : {
                'code' : '02',
                'subDist' : {'M区' : '01','Z区' : '02'}
            }
        }
    },

    'Liyue省' : {
        'code' : '01',
        'subCity' : {
            'Y市' : {
                'code' : '01',
                'subDist' : {'L区' : '01','G区' : '02'}
            },
            'M市' : {
                'code' : '02',
                'subDist' : {'Q区' : '01','J区' : '02','H区' : '03'}
            },
            'B市' : {
                'code' : '03',
                'subDist' : {'Q区' : '01'}
            }
        }
    }
}


OFFICER = {
    1 : '流行病学调查员',
    2 : '采样员',
    3 : '医师'
}

def getCity(Prov:str) ->list:
    return list(TEYVAT[Prov]['subCity'].keys())

def getDist(Prov:str, City:str) ->list:
    #print(Prov, City)
    return list(TEYVAT[Prov]['subCity'][City]['subDist'].keys())
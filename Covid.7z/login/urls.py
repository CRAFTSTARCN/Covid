from django.contrib import admin
from django.urls import path, include
from login import views

urlpatterns = [
    path('officer/',views.loginOfficer),
    path('admin/', views.loginAdmin),
    path('checkAdmin/', views.checkAdmin),
    path('checkOfficer/', views.checkOfficer),
]
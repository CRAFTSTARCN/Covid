from django.shortcuts import render
from django.http import JsonResponse
from BaseInfo import query, info
from django.core.handlers.wsgi import WSGIRequest
from django.db import connections,transaction
import datetime
from hashlib import sha256

# API

def doctorGetTestInfo(request : WSGIRequest):
    if request.method == 'POST' or request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Fault'})
    
    i,n = request.GET.get('Id'), request.GET.get('Name')

    if not query.nameIdVerify(i,n) :
        return JsonResponse({'code' : -1, 'Message' : '查无此人'})

    res = query.QueryTest(i,request.session.get('WorkProv'),request.session.get('WorkCity'),'0001-01-01')

    resDict = {'code' : 1}
    resList = []

    for tu in res:
        if tu[2] == 'U':
            resList.append({'Id' : tu[0], 'Time' : tu[1]})
    
    resDict.update({'ResList' : resList})
    return JsonResponse(resDict)


def markOne(request : WSGIRequest):
    if request.method == 'GET' or request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Fault'})

    i,t,r = request.POST.get('MarkId'), request.POST.get('MarkTime'), request.POST.get('MarkRes')
    cursor = connections['default'].cursor()

    exeMark = '''
    UPDATE TestCase
    SET Resault = %s, Laboratorian = %s
    WHERE Id = %s AND TestTime = %s
    AND Resault = \'U\';
    '''

    exeContact = '''
    UPDATE CloseContact
    SET TestResault = %s
    WHERE Id = %s
    AND ContactTime < %s
    AND TestResault = 'U';
    '''

    transaction.set_autocommit(False)
    try:
        cursor.execute(exeMark,(r,request.session.get('userId'),i,t))
        cursor.execute(exeContact,(r,i,t))
    except Exception as e :
        print(e)
        connections['default'].rollback()
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Update error'})
    
    connections['default'].commit()
    transaction.set_autocommit(True)
    
    NewPos = False
    if r == 'P':
        cursor.execute("SELECT ConfirmTime FROM Infected WHERE Id = %s ORDER BY ConfirmTime DESC",(i))
        inf = cursor.fetchall()
        cursor.execute("SELECT RecoverTime FROM Recovered NATURAL JOIN Infected  WHERE Id = %s ORDER BY RecoverTime DESC",(i))
        rec = cursor.fetchall()

        if inf.__len__() == 0:
            NewPos = True
        elif inf.__len__() == rec.__len__() and rec[0][0].strftime("%Y-%m-%d") < t :
            NewPos = True

    return JsonResponse({'code' : 1, 'message' : 'Success', 'NewPos' : NewPos})


def insertInfected(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})
    
    i,n = request.POST.get('Id'),  request.POST.get('Name')
    valid = query.nameIdVerify(i,n)

    if not valid:
        return JsonResponse({'code' : -1, 'message' : 'Id 姓名错误'})
    
    p = request.POST.get("password")
    hasher = sha256()
    hasher.update(p.encode('utf-8'))
    if hasher.hexdigest() != request.session.get('userKey'):
        return JsonResponse({'code' : -1, 'message' : 'Worng Password'})
    
    t,d = request.POST.get('Time'), request.POST.get('Dist')
    p,c = request.session.get('WorkProv'), request.session.get('WorkCity')

    cursor = connections['default'].cursor()
    cursor.execute('SELECT COUNT(CaseNumber) FROM Infected;')
    CaseNum = cursor.fetchone()[0]

    exe = ''' INSERT INTO Infected
    VALUES(%s,%s,%s,%s,%s,%s);
    '''

    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(CaseNum,i,t,p,c,d))
    except Exception as e:
        print(e)
        connections['default'].rollback()
        transaction.set_autocommit(True)
        cursor.close()
        return JsonResponse({'code' : -1, 'message' : 'Insert error'})
    
    connections['default'].commit()
    transaction.set_autocommit(True)
    return JsonResponse({'code' : 1, 'message' : 'success'})


def insertRecovered(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})
    
    p = request.POST.get('password')
    hasher = sha256()
    hasher.update(p.encode('utf-8'))

    if hasher.hexdigest() != request.session.get('userKey'):
        return JsonResponse({'code' : -1, 'message' : 'wrong password'})
    
    cn,i = request.POST.get('CaseNumber'), request.POST.get('Id')
    if not i.isdigit():
        JsonResponse({'code' : -1, 'message' : '病历号应为数字'})
    i = int(i)

    cursor = connections['default'].cursor()
    cursor.execute("SELECT * FROM Infected WHERE CaseNumber = %s AND Id = %s;",(cn,i))

    if cursor.fetchone() == None:
        return JsonResponse({'code' : -1, 'message' : 'ID 病历号错误，请检查'})
    
    cursor.execute("SELECT * FROM DeadCase WHERE CaseNumber = %s;",(cn))
    if cursor.fetchone() != None:
        return JsonResponse({'code' : -1, 'message' : '病例已经死亡'})

    t = request.POST.get('Time')

    exe = '''INSERT INTO Recovered
    VALUES(%s,%s);
    '''
    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(cn,t))
    except Exception as e:
        connections['default'].rollback()
        print(e)
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Insert Error'})

    connections['default'].commit()
    transaction.set_autocommit(True)
    cursor.close()

    return JsonResponse({'code' : 1, 'message' : 'success'})


def insertDead(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})
    
    p = request.POST.get('password')
    hasher = sha256()
    hasher.update(p.encode('utf-8'))

    if hasher.hexdigest() != request.session.get('userKey'):
        return JsonResponse({'code' : -1, 'message' : 'wrong password'})
    
    cn,i = request.POST.get('CaseNumber'), request.POST.get('Id')
    if not i.isdigit():
        JsonResponse({'code' : -1, 'message' : '病历号应为数字'})
    i = int(i)
    cursor = connections['default'].cursor()
    cursor.execute("SELECT * FROM Infected WHERE CaseNumber = %s AND Id = %s;",(cn,i))

    if cursor.fetchone() == None:
        return JsonResponse({'code' : -1, 'message' : 'ID 病历号错误，请检查'})
    
    cursor.execute("SELECT * FROM Recovered WHERE CaseNumber = %s;",(cn))
    if cursor.fetchone() != None:
        return JsonResponse({'code' : -1, 'message' : '病例状态为治愈'})
    
    t = request.POST.get('Time')

    exe = '''
    INSERT INTO DeadCase
    VALUES(%s,%s);
    '''

    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(cn,t))
    except Exception as e:
        connections['default'].rollback()
        print(e)
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Insert Error'})
    
    connections['default'].commit()
    transaction.set_autocommit(True)
    cursor.close()

    return JsonResponse({'code' : 1, 'message' : 'success'})


def queryInfected(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})

    c,i,n = request.GET.get('CaseNumber'),request.GET.get('Id'),request.GET.get('Name')
    if c == '' and i == '' and n == '' :
        return JsonResponse({'code' : -1, 'message' : '输入查询条件'})

    if c != '' and (not c.isdigit()):
        return JsonResponse({'code' : -1, 'message' : '病历号应为数字'})
    if i != '' and (not i.isdigit()):
        return JsonResponse({'code' : -1, 'message' : 'ID应为数字'})
    
    if c=='' and i=='' and n == '%' :
        return JsonResponse({'code' : -1, 'message' : 'You can\'t only input % for name '})

    c = '%' if c == '' else c
    i = '%' if i == '' else i
    n = '%' if n == '' else n


    resList = []
    cursor = connections['default'].cursor()

    qexe = '''SELECT CaseNumber, LastName, FirstName, Id, ConfirmTime,
    InProv, InCity, InDistrict,
    CaseNumber NOT IN (SELECT CaseNumber FROM Recovered) rec,
    CaseNumber NOT IN (SELECT CaseNumber FROM DeadCase) dea
    FROM Infected NATURAL JOIN Resident
    WHERE CONCAT(LastName,FirstName) LIKE %s AND Id LIKE %s 
    AND CONCAT(CaseNumber,'') LIKE %s;
    ''' 

    cursor.execute(qexe,(n,i,c))
    res = cursor.fetchall()

    for tu in res:
        resList.append(list(tu))
    cursor.close()
    return JsonResponse({'code' : 1, 'message' : 'success', 'resList' : resList})


def batchQuery(request : WSGIRequest):
    if request.method == 'POST':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})

    bn = request.GET.get('BatchNumber','')
    if not bn.isdigit():
        return JsonResponse({'code' : -1, 'message' : 'Batch number should be a digit'})
    
    p = info.TEYVAT[request.session.get('WorkProv')]['code']
    c = info.TEYVAT[request.session.get('WorkProv')]['subCity'][request.session.get('WorkCity')]['code']
    if bn[-4:] != p+c:
        return JsonResponse({'code' : -1, 'message' : 'Invalid batch number'})
    
    bn = int(bn)
    cursor = connections['default'].cursor()
    qexe = ''' SELECT LastName, FirstName, Id, TestTime
    FROM TestCase NATURAL JOIN Resident
    WHERE Batch = %s AND Resault = \'U\';
    '''
    cursor.execute(qexe,(bn))
    cres = cursor.fetchall()

    ResList = []
    for tu in cres:
        ResList.append(list(tu))

    cursor.close()
    return JsonResponse({'code' : 1, 'message' : 'success', 'ResList' : ResList, 'Place' : request.session.get('WorkProv') + request.session.get('WorkCity')})


def batchMark(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) != 3:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})

    p = request.POST.get('password','')
    hasher = sha256()
    hasher.update(p.encode('utf-8'))
    if hasher.hexdigest() != request.session.get('userKey'):
        return JsonResponse({'code' : -1, 'message' : 'wrong password'})

    bn = request.POST.get('BatchNumber','')
    if not bn.isdigit():
        return JsonResponse({'code' : -1, 'message' : 'Batch number should be a digit'})
    
    p = info.TEYVAT[request.session.get('WorkProv')]['code']
    c = info.TEYVAT[request.session.get('WorkProv')]['subCity'][request.session.get('WorkCity')]['code']
    if bn[-4:] != p+c:
        return JsonResponse({'code' : -1, 'message' : 'Invalid batch number'})
    
    bn = int(bn)
    cursor = connections['default'].cursor()
    exe = '''
    UPDATE TestCase
    SET Resault = \'N\', Laboratorian = %s
    WHERE Batch = %s AND Resault = \'U\';
    '''

    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(request.session.get('userId'),bn))
    except Exception as e:
        connections['default'].rollback()
        print(e)
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Insert Error'})
    
    connections['default'].commit()
    transaction.set_autocommit(True)
    cursor.close()
    return JsonResponse({'code' : 1, 'message' : 'success'})


def insertTestCase(request : WSGIRequest):
    if request.method == 'GET':
        return JsonResponse({'code' : -1, 'message' : 'API Error, Request Error'})
    if request.session.get('userDuty',-1) < 2:
        return JsonResponse({'code' : -1, 'message' : 'API Error, No permition'})
    
    TestResault = request.POST.get('Resault','U') if request.session.get('userDuty') == 3 else 'U'
    lab = request.session.get('userId') if request.session.get('userDuty') == 3 else None
    i,n = request.POST.get('Id'), request.POST.get('Name')
    valid = query.nameIdVerify(i,n)
    if not valid:
        return JsonResponse({'code' : -1, 'message' : 'ID 姓名错误'})
    
    bn = request.POST.get('BatchNumber','')
    if bn != '' and (not bn.isdigit()):
        return JsonResponse({'code' : -1, 'message' : '错误的批号格式'})
    
    if bn != '':
        p = info.TEYVAT[request.session.get('WorkProv')]['code']
        c = info.TEYVAT[request.session.get('WorkProv')]['subCity'][request.session.get('WorkCity')]['code']
        if bn[-4:] != p+c:
            return JsonResponse({'code' : -1, 'message' : 'Invalid batch number'})

    if bn == '':
        bn = None
    t = request.POST.get('Time')

    exe = ''' INSERT INTO TestCase
    VALUES(%s,%s,%s,%s,%s,%s)
    '''

    cursor = connections['default'].cursor()
    transaction.set_autocommit(False)
    try:
        cursor.execute(exe,(i,request.session.get('userId'),lab,t,TestResault,bn))
    except Exception as e:
        connections['default'].rollback()
        print(e)
        cursor.close()
        transaction.set_autocommit(True)
        return JsonResponse({'code' : -1, 'message' : 'Insert Error'})
    
    connections['default'].commit()
    transaction.set_autocommit(True)
    cursor.close()
    return JsonResponse({'code' : 1, 'message' : 'success'})


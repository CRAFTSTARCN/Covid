from django.apps import AppConfig


class AdfunctionConfig(AppConfig):
    name = 'AdFunction'
